# AutoSafe_Temperatura_v6.0.7_big_ux_update

Patch zbiorczy od punktu 3 ustaleń UX.

## Zmienione obszary
- Dodawanie czujnika jako lista znalezionych urządzeń.
- Dopasowanie ręczne po nazwie i końcówce, np. 9019F4.
- Kompaktowy pulpit i mniejsze Centrum monitoringu.
- Automatyczne odświeżanie przy otwartej aplikacji.
- Ustawienia częstotliwości i trybu tła.
- Zakładka Czujniki jako lista z detalami po kliknięciu.
- Widoczne ikony czujników.
- Ustawienia jako accordiony.
- Grupy czujników.
- Plan v6.1 dla Android Foreground Service.

## Nie ruszać
- 0x2A6E temperatura.
- 0x2A6F wilgotność RHT.
- 0x0757 bateria.
- Logo AutoSafe.
- Android/Capacitor.
