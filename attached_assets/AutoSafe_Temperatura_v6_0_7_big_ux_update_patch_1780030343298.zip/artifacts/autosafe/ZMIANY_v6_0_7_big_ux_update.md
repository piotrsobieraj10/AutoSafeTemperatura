# AutoSafe_Temperatura_v6.0.7_big_ux_update

Duży patch UX od punktu 3 ustaleń:

- dodawanie czujnika pokazuje listę znalezionych urządzeń zamiast automatycznie dodawać pierwszy wynik,
- ręczne dopasowanie działa po pełnej nazwie i samej końcówce, np. `9019F4`,
- ekran konfiguracji czujnika ma pionowy scroll i układ dopasowany do telefonu,
- pulpit główny ma mniejsze Centrum monitoringu i kompaktowe karty,
- przy otwartej aplikacji dodano automatyczne odświeżanie co 30 s z ustawieniem częstotliwości,
- ustawienia monitoringu w tle przygotowane pod v6.1,
- zakładka Czujniki została uproszczona do kompaktowej listy,
- szczegóły czujnika otwierają akcje: Edytuj, Alarmy, Kalibracja, Historia, Diagnostyka BLE, Usuń,
- ikony czujników są teraz widoczne w UI,
- Ustawienia są podzielone na rozwijane sekcje,
- Obsługiwane czujniki są kartą rozwijaną,
- dodano grupy czujników: Dom/Garaż/Inne oraz możliwość tworzenia własnych grup,
- stare czujniki bez grupy dostają domyślną grupę,
- dekodery BLE pozostają bez zmian: 0x2A6E temperatura, 0x2A6F wilgotność RHT, 0x0757 bateria.
