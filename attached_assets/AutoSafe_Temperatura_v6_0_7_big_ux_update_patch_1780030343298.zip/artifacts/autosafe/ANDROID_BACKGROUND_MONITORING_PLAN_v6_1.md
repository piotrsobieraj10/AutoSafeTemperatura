# AutoSafe_Temperatura v6.1 — plan monitoringu w tle Android APK

## Cel
Aplikacja ma zbierać pomiary z ELA Blue PUCK T/RHT również po wygaszeniu ekranu, ale bez agresywnego zużycia baterii.

## Założenia
- Przy otwartej aplikacji: automatyczny odczyt co 30 sekund domyślnie.
- W tle: Android Foreground Service ze stałym powiadomieniem „AutoSafe monitoruje czujniki”.
- Nie używać ciągłego skanowania BLE jako domyślnego trybu.
- Zapisywać historię tylko przy nowej ramce albo realnej zmianie danych.

## Tryby w tle
1. Wyłączony — brak pracy w tle.
2. Oszczędny — co 5 minut, skan 20 sekund. Tryb domyślny.
3. Normalny — co 2 minuty, skan 20 sekund.
4. Testowy — co 30 sekund, maksymalnie 15 minut.

## Wymagania Android
- Foreground Service.
- Powiadomienie stale widoczne podczas monitoringu.
- Instrukcja wyłączenia optymalizacji baterii dla AutoSafe Temperatura.
- Obsługa braku uprawnień Nearby devices / Bluetooth / lokalizacji tam, gdzie Android tego wymaga.

## Ograniczenia
Android może ograniczać skanowanie BLE w tle, szczególnie przy oszczędzaniu baterii. Dlatego tryb tła ma być cykliczny i krótki, a nie ciągły.
