# AutoSafe Temperatura v6.0.8 auto refresh audit fix

Wersja UI: `AutoSafe_Temperatura_v6.0.8_auto_refresh_audit_fix`

## Przyczyna problemu

Auto-refresh po patchu UX v6.0.7 byl rozproszony po ekranie Dashboard i nie dzialal jako staly mechanizm aplikacji. Po przejsciu na inna zakladke timer znikal, reczny i automatyczny refresh mogly wejsc sobie w droge, a ustawienia nie mialy osobnego eventu do natychmiastowego przeladowania timera. Dodatkowo sanityzacja localStorage przy starcie nadpisywala starsze ustawienie monitoringu, co moglo wygladac jak losowe wylaczanie odswiezania po migracji.

## Zmienione pliki

- `artifacts/autosafe/src/components/AppShell.tsx`
- `artifacts/autosafe/src/components/SensorCard.tsx`
- `artifacts/autosafe/src/config/app.ts`
- `artifacts/autosafe/src/hooks/useSensors.ts`
- `artifacts/autosafe/src/pages/DashboardPage.tsx`
- `artifacts/autosafe/src/pages/SensorsPage.tsx`
- `artifacts/autosafe/src/pages/SettingsPage.tsx`
- `artifacts/autosafe/src/services/autoRefreshService.ts`
- `artifacts/autosafe/src/services/bluetoothService.ts`
- `artifacts/autosafe/src/services/nativeBleService.ts`
- `artifacts/autosafe/src/services/storageService.ts`

## Jak dziala teraz auto-refresh

- Centralny timer dziala w `AppShell`, wiec nie znika po przejsciu z Dashboard na inne zakladki aplikacji.
- Domyslnie auto-refresh jest wlaczony co 30 sekund.
- Dostepne opcje: recznie, 15 s, 30 s, 60 s, 2 min.
- Timer dziala tylko, gdy aplikacja jest widoczna. Po powrocie do aplikacji harmonogram startuje ponownie.
- Automatyczny skan BLE uzywa krotkiego okna 15 sekund.
- Jesli skan juz trwa, kolejny cykl jest pomijany i zapisywany jako status diagnostyczny, bez duzego alertu w UI.
- Reczny przycisk `Odśwież wszystkie` nadal wywoluje ten sam bezpieczny mechanizm.
- Po nowej ramce aktualizowane sa: temperatura, wilgotnosc RHT, bateria, RSSI, ostatni odczyt i status zapisu.
- Gdy kolejna ramka zawiera tylko czesc danych, poprzednia bateria lub wilgotnosc nie sa kasowane.
- Historia nie jest spamowana co 30 sekund: zapis pomiaru jest pomijany, jesli przez mniej niz 60 s nie zmienila sie temperatura o 0,2 C, wilgotnosc o 1%, bateria ani RSSI.

## APK

W Android APK refresh dla czujnikow ELA advertisement przechodzi przez `nativeBleService.ts` i natywny plugin `AutosafeBle`. Plugin nadal zabezpiecza `scanner == null`, `startScan` ma `try/catch`, a listener zdarzen idzie przez glowny watek. Nie dodawano Foreground Service w tej wersji.

Test APK:

1. Zainstaluj patch.
2. Uruchom `PORT=3000 BASE_PATH=/ pnpm --filter @workspace/autosafe run build`.
3. Uruchom `pnpm exec cap sync android`.
4. Zbuduj APK standardowym procesem projektu.
5. Otworz aplikacje, zostaw ekran aktywny i sprawdz, czy status pokazuje `Auto odświeżanie: co 30 s`, `Skanowanie trwa...`, `Ostatnie odświeżenie` oraz nowe wartosci na kartach.

## PWA

PWA nadal uzywa Web Bluetooth tam, gdzie przegladarka na to pozwala. Jezeli przegladarka blokuje automatyczne BLE bez gestu uzytkownika, aplikacja pokazuje prosty komunikat:

`Automatyczne odświeżanie BLE działa stabilnie w aplikacji Android. W przeglądarce może wymagać ręcznego uruchomienia.`

Test PWA:

1. Otworz aplikacje w Chrome/HTTPS.
2. Dodaj lub odswiez czujnik recznie, aby nadac zgode Bluetooth.
3. Zostaw aplikacje widoczna i obserwuj status auto-refresh.
4. Jesli Chrome wymaga gestu uzytkownika, uzyj recznego `Odśwież wszystkie`.

## Czego nie ruszano

Nie zmieniano dekoderow BLE:

- `0x2A6E` temperatura `int16LE / 100`
- `0x2A6F` wilgotnosc RHT: `1 bajt procentow + fallback 2 bajty / 100`
- `0x0757` bateria `mV`

Nie usuwano Androida, PWA, logo AutoSafe, grup czujnikow, kompaktowych kart, ustawien ani list rozwijanych z v6.0.7.
