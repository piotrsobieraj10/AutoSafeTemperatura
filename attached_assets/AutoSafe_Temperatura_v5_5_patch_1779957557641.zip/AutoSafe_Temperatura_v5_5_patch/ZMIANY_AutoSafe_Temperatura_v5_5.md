# AutoSafe_Temperatura_v5.5

Wersja ekspercka po testach ELA Blue PUCK T/RHT.

## Najważniejsze zmiany

- Podmieniono logo na autentyczne złote logo AutoSafe z przesłanego materiału.
- Dodano pliki PWA z prawdziwym logo: `autosafe-logo-zlote.png`, `autosafe-icon-192.png`, `autosafe-icon-512.png`.
- Ustawiono wersję UI na `AutoSafe_Temperatura_v5.5`.
- Dodano pulpit główny jako centrum monitoringu: średnia temperatura, wilgotność, online, bateria, alerty.
- Dodano przycisk `Monitoruj wszystkie`, który uruchamia nasłuch BLE dla zapisanych czujników ELA.
- Dopracowano karty czujników: temperatura, wilgotność, bateria, RSSI, ostatni odczyt, nazwa BLE i status.
- Diagnostyka BLE jest teraz opcjonalna i sterowana przełącznikiem w ustawieniach.
- Dodano/rozszerzono obsługę wilgotności `0x2A6F` dla ELA Blue PUCK RHT.
- Zachowano dane z różnych ramek BLE: temperatura, wilgotność i bateria nie znikają, gdy następna ramka ma tylko część danych.
- Dodano kalibrację czujnika: korekta temperatury i wilgotności.
- Dodano alerty temperatury, wilgotności, offline i słabej baterii.
- Dodano czytelny panel edycji czujnika: nazwa, opis, ikona, profil, progi, kalibracja.
- Dodano historię z min/avg/max, średnią wilgotnością i eksport CSV.
- Dodano backup/import JSON z poziomu ustawień.
- Poprawiono status online/offline na podstawie świeżości ostatniej ramki BLE.

## Test po wgraniu

1. Uruchom `npm run build`.
2. Otwórz aplikację na Androidzie w Chrome.
3. Zamknij nRF Connect.
4. Kliknij `Monitoruj wszystkie` albo `Nasłuchuj BLE` na wybranym czujniku.
5. Poczekaj 1–2 minuty blisko czujników.
6. Sprawdź: temperatura, wilgotność RHT, bateria, RSSI, ostatni odczyt.
7. W ustawieniach możesz włączyć `Pokaż diagnostykę BLE`, jeśli chcesz widzieć raw serviceData/manufacturerData.
