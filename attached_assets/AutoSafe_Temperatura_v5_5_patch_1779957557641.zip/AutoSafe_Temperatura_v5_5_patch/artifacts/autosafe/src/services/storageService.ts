// storageService.ts v5.5 — stabilne dane lokalne, eksport, raporty i ustawienia AutoSafe
import type { AlertEvent, AppSettings, Measurement, Sensor } from "@/types/sensor";
export type { AppSettings } from "@/types/sensor";

const K = {
  SENSORS:      "thermo.v2.sensors",
  MEASUREMENTS: "thermo.v2.measurements",
  SETTINGS:     "thermo.v2.settings",
  ALERTS:       "thermo.v2.alerts",
};

const MAX_MEASUREMENTS = 20_000;
const MAX_ALERTS       = 500;

const read = <T>(key: string, fb: T): T => {
  try { const r = localStorage.getItem(key); return r ? JSON.parse(r) : fb; }
  catch { return fb; }
};

const write = (key: string, val: unknown) => {
  try { localStorage.setItem(key, JSON.stringify(val)); }
  catch (e) {
    if (e instanceof DOMException && e.name === "QuotaExceededError") {
      const ms = getMeasurements().slice(-Math.floor(MAX_MEASUREMENTS / 2));
      localStorage.setItem(K.MEASUREMENTS, JSON.stringify(ms));
      try { localStorage.setItem(key, JSON.stringify(val)); } catch {}
    }
  }
};

export const emitDataChanged = () => {
  try { window.dispatchEvent(new CustomEvent("autosafe:data-changed")); } catch {}
};

// ── Sensors ─────────────────────────────────────────────────
export const getSensors = (): Sensor[] => read<Sensor[]>(K.SENSORS, []).map((s) => ({
  ...s,
  temperatureOffset: s.temperatureOffset ?? 0,
  humidityOffset: s.humidityOffset ?? 0,
  offlineAlertMinutes: s.offlineAlertMinutes ?? 30,
}));

export const saveSensors = (s: Sensor[]) => { write(K.SENSORS, s); emitDataChanged(); };

export const upsertSensor = (s: Sensor): void => {
  const list = getSensors();
  const i = list.findIndex((x) => x.id === s.id);
  i >= 0 ? (list[i] = s) : list.push(s);
  saveSensors(list);
};

export const deleteSensor = (id: string): void => {
  saveSensors(getSensors().filter((s) => s.id !== id));
  write(K.MEASUREMENTS, getMeasurements().filter((m) => m.sensorId !== id));
  emitDataChanged();
};

export const patchSensor = (id: string, patch: Partial<Sensor>): void => {
  const s = getSensors().find((x) => x.id === id);
  if (s) upsertSensor({ ...s, ...patch });
};

// ── Measurements ────────────────────────────────────────────
export const getMeasurements = (): Measurement[] => read<Measurement[]>(K.MEASUREMENTS, []);

export const addMeasurement = (m: Measurement): void => {
  const list = getMeasurements();
  // nie zapisuj identycznego pomiaru częściej niż co 15 sekund dla tego samego czujnika
  const last = [...list].reverse().find((x) => x.sensorId === m.sensorId);
  if (last) {
    const dt = new Date(m.createdAt).getTime() - new Date(last.createdAt).getTime();
    const sameTemp = Math.abs((last.temperature ?? 0) - (m.temperature ?? 0)) < 0.005;
    const sameHum = (last.humidity ?? -1) === (m.humidity ?? -1);
    const sameBat = (last.batteryVoltage ?? -1) === (m.batteryVoltage ?? -1);
    if (dt >= 0 && dt < 15_000 && sameTemp && sameHum && sameBat) return;
  }
  list.push(m);
  write(K.MEASUREMENTS, list.slice(-MAX_MEASUREMENTS));
  emitDataChanged();
};

export const getMeasurementsForSensor = (sensorId: string, sinceMs?: number): Measurement[] => {
  const all = getMeasurements().filter((m) => m.sensorId === sensorId);
  if (!sinceMs) return all;
  const cutoff = Date.now() - sinceMs;
  return all.filter((m) => new Date(m.createdAt).getTime() >= cutoff);
};

export const clearMeasurements = (sensorId: string): void => {
  write(K.MEASUREMENTS, getMeasurements().filter((m) => m.sensorId !== sensorId));
  emitDataChanged();
};

export const clearAllMeasurements = (): void => { write(K.MEASUREMENTS, []); emitDataChanged(); };

// ── Alerts history ───────────────────────────────────────────
export const getAlerts = (): AlertEvent[] => read<AlertEvent[]>(K.ALERTS, []);
export const addAlert = (a: AlertEvent): void => {
  const list = getAlerts();
  const duplicate = list.slice(-20).some((x) => x.sensorId === a.sensorId && x.type === a.type && Date.now() - new Date(x.createdAt).getTime() < 15 * 60_000);
  if (duplicate) return;
  list.push(a);
  write(K.ALERTS, list.slice(-MAX_ALERTS));
  emitDataChanged();
};
export const acknowledgeAlert = (id: string): void => {
  const list = getAlerts().map((a) => a.id === id ? { ...a, acknowledged: true } : a);
  write(K.ALERTS, list);
  emitDataChanged();
};
export const clearAlerts = (): void => { write(K.ALERTS, []); emitDataChanged(); };

// ── Settings ─────────────────────────────────────────────────
export const DEFAULT_SETTINGS: AppSettings = {
  demoMode:          false,
  theme:             "system",
  tempUnit:          "C",
  scanDuration:      10_000,
  pollingInterval:   30_000,
  alertSound:        false,
  alertVibration:    true,
  chartDefaultRange: "24h",
  maxMeasurements:   MAX_MEASUREMENTS,
  dashboardDensity:  "comfortable",
  showBleDiagnostics:false,
  autoStartMonitor:  false,
};

export const getSettings = (): AppSettings => ({ ...DEFAULT_SETTINGS, ...read<Partial<AppSettings>>(K.SETTINGS, {}) });
export const saveSettings = (s: AppSettings) => { write(K.SETTINGS, s); emitDataChanged(); };
export const patchSettings = (patch: Partial<AppSettings>) => saveSettings({ ...getSettings(), ...patch });

// ── Helpers ──────────────────────────────────────────────────
export const toDisplayTemp = (c: number, unit: "C" | "F") => unit === "F" ? +(c * 9 / 5 + 32).toFixed(1) : c;
export const formatTemp = (c: number | undefined, unit: "C" | "F"): string => c == null ? "—" : `${toDisplayTemp(c, unit).toFixed(1)}°${unit}`;
export const formatHumidity = (h: number | undefined): string => h == null ? "—" : `${h.toFixed(0)}%`;
export const formatPressure = (p: number | undefined): string => p == null ? "—" : `${p.toFixed(1)} hPa`;
export const formatBattery = (mv?: number, pct?: number): string => {
  if (pct != null && mv != null) return `${pct}% · ${mv} mV`;
  if (pct != null) return `${pct}%`;
  if (mv != null) return `${mv} mV`;
  return "czekam na ramkę baterii";
};

export const getBatteryLabel = (mv?: number, pct?: number): { label: string; tone: "ok" | "warn" | "bad" | "unknown" } => {
  if (pct != null) {
    if (pct < 15) return { label: "niska", tone: "bad" };
    if (pct < 35) return { label: "średnia", tone: "warn" };
    return { label: "dobra", tone: "ok" };
  }
  if (mv == null) return { label: "oczekuje", tone: "unknown" };
  if (mv < 2400) return { label: "niska", tone: "bad" };
  if (mv < 2850) return { label: "średnia", tone: "warn" };
  return { label: "dobra", tone: "ok" };
};

export const exportCsv = (): string => {
  const sensors = getSensors();
  const sensorById = new Map(sensors.map((s) => [s.id, s]));
  const rows = [["data", "pomieszczenie", "nazwa_ble", "temperatura_c", "wilgotnosc_pct", "bateria_mv", "rssi"]];
  getMeasurements().forEach((m) => {
    const s = sensorById.get(m.sensorId);
    rows.push([
      m.createdAt,
      m.roomName,
      m.bluetoothName ?? s?.bluetoothName ?? "",
      String(m.temperature ?? ""),
      String(m.humidity ?? ""),
      String(m.batteryVoltage ?? ""),
      String(m.rssi ?? ""),
    ]);
  });
  return rows.map((r) => r.map((v) => `"${String(v).replace(/"/g, '""')}"`).join(";")).join("\n");
};

export const createBackupJson = (): string => JSON.stringify({
  version: "AutoSafe_Temperatura_v5.5",
  exportedAt: new Date().toISOString(),
  sensors: getSensors(),
  measurements: getMeasurements(),
  alerts: getAlerts(),
  settings: getSettings(),
}, null, 2);

export const importBackupJson = (json: string): void => {
  const data = JSON.parse(json) as Partial<{ sensors: Sensor[]; measurements: Measurement[]; alerts: AlertEvent[]; settings: AppSettings }>;
  if (Array.isArray(data.sensors)) write(K.SENSORS, data.sensors);
  if (Array.isArray(data.measurements)) write(K.MEASUREMENTS, data.measurements.slice(-MAX_MEASUREMENTS));
  if (Array.isArray(data.alerts)) write(K.ALERTS, data.alerts.slice(-MAX_ALERTS));
  if (data.settings) write(K.SETTINGS, { ...DEFAULT_SETTINGS, ...data.settings });
  emitDataChanged();
};

export const downloadTextFile = (filename: string, content: string, mime = "text/plain;charset=utf-8") => {
  const blob = new Blob([content], { type: mime });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  a.click();
  setTimeout(() => URL.revokeObjectURL(url), 1500);
};
