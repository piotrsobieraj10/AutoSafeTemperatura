// pages/DashboardPage.tsx v5.5 — centrum monitoringu AutoSafe
import { useMemo, useState } from "react";
import type { ReactNode } from "react";
import { Button } from "@/components/ui/button";
import { Plus, AlertTriangle, TrendingDown, TrendingUp, Thermometer, Radio, Droplets, BatteryMedium, Wifi, Activity } from "lucide-react";
import { SensorCard } from "@/components/SensorCard";
import { AddSensorModal } from "@/components/AddSensorModal";
import { useSensors } from "@/hooks/useSensors";
import { formatHumidity, formatTemp, getSettings } from "@/services/storageService";
import { getTempZone } from "@/types/sensor";
import { cn } from "@/lib/utils";
import { toast } from "sonner";

export function DashboardPage() {
  const { sensors, upsert, alertSensors, refresh, listen, listenAll, pinnedSensors, unpinnedSensors } = useSensors();
  const [addOpen, setAddOpen] = useState(false);
  const [monitoring, setMonitoring] = useState(false);
  const settings = getSettings();

  const connected = sensors.filter((s) => s.lastReadAt && Date.now() - new Date(s.lastReadAt).getTime() < 120_000);
  const withTemp = sensors.filter((s) => s.lastTemperature != null);
  const withHumidity = sensors.filter((s) => s.lastHumidity != null);
  const avgTemp = withTemp.length > 0 ? withTemp.reduce((a, s) => a + (s.lastTemperature ?? 0), 0) / withTemp.length : null;
  const avgHumidity = withHumidity.length > 0 ? withHumidity.reduce((a, s) => a + (s.lastHumidity ?? 0), 0) / withHumidity.length : null;
  const minSensor = withTemp.reduce<typeof sensors[0] | null>((a, s) => !a || (s.lastTemperature! < a.lastTemperature!) ? s : a, null);
  const maxSensor = withTemp.reduce<typeof sensors[0] | null>((a, s) => !a || (s.lastTemperature! > a.lastTemperature!) ? s : a, null);
  const lowBattery = sensors.filter((s) => (s.batteryLevel != null && s.batteryLevel < 20) || (s.batteryVoltage != null && s.batteryVoltage < 2400));

  const cards = useMemo(() => [...unpinnedSensors], [unpinnedSensors]);
  const handlePin = (s: typeof sensors[0]) => upsert({ ...s, isPinned: !s.isPinned });
  const handleMute = (s: typeof sensors[0]) => upsert({ ...s, alertMuted: !s.alertMuted });

  const handleMonitorAll = async () => {
    setMonitoring(true);
    toast.info("Start monitoringu BLE — trzymaj telefon blisko czujników przez 1–2 minuty.");
    const ok = await listenAll();
    setMonitoring(false);
    if (ok) toast.success("Monitoring BLE uruchomiony. Odczyty będą pojawiać się po odebraniu reklam czujników.");
    else toast.warning("Nie udało się uruchomić skanu BLE. Sprawdź Chrome, Bluetooth i uprawnienia.");
  };

  return (
    <div className="space-y-8">
      <section className="relative overflow-hidden rounded-3xl bg-gradient-hero p-7 text-white shadow-glow noise sm:p-8">
        <div className="absolute -right-16 -top-16 h-64 w-64 rounded-full bg-white/10 blur-3xl pointer-events-none" />
        <div className="absolute -bottom-24 -left-8 h-56 w-56 rounded-full bg-white/8 blur-3xl pointer-events-none" />
        <div className="relative z-10 flex flex-wrap items-end justify-between gap-5">
          <div>
            <p className="text-sm font-medium opacity-75">{new Date().toLocaleDateString("pl-PL", { weekday: "long", day: "numeric", month: "long" })}</p>
            <h1 className="mt-1 font-display text-4xl font-black leading-tight sm:text-5xl">Monitoring AutoSafe</h1>
            <p className="mt-2 max-w-xl text-sm opacity-80">Jeden pulpit dla temperatury, wilgotności, baterii i zasięgu czujników ELA Blue PUCK.</p>
          </div>
          <div className="flex flex-col gap-2 sm:flex-row">
            <Button size="lg" onClick={handleMonitorAll} disabled={monitoring || sensors.length === 0} className="bg-primary text-primary-foreground hover:bg-primary/90 shadow-glow">
              <Radio className={cn("mr-2 h-4 w-4", monitoring && "animate-pulse")} />{monitoring ? "Nasłuchuję…" : "Monitoruj wszystkie"}
            </Button>
            <Button size="lg" onClick={() => setAddOpen(true)} className="bg-white/20 hover:bg-white/30 border border-white/25 text-white backdrop-blur shadow-none">
              <Plus className="mr-2 h-4 w-4" /> Dodaj czujnik
            </Button>
          </div>
        </div>
        <div className="relative z-10 mt-6 grid grid-cols-2 gap-3 sm:grid-cols-4">
          <StatPill icon={<Thermometer className="h-4 w-4" />} label="Średnia" value={avgTemp != null ? formatTemp(avgTemp, settings.tempUnit) : "—"} sub={`${connected.length}/${sensors.length} online`} />
          <StatPill icon={<Droplets className="h-4 w-4" />} label="Wilgotność" value={avgHumidity != null ? formatHumidity(avgHumidity) : "—"} sub="RHT" />
          <StatPill icon={<Wifi className="h-4 w-4" />} label="Odczyty" value={`${connected.length}`} sub="świeże 120 s" />
          <StatPill icon={<BatteryMedium className="h-4 w-4" />} label="Bateria" value={lowBattery.length ? `${lowBattery.length}` : "OK"} sub={lowBattery.length ? "do sprawdzenia" : "brak alertów"} />
        </div>
      </section>

      {alertSensors.filter((s) => !s.alertMuted).length > 0 && (
        <section className="rounded-2xl border border-destructive/30 bg-destructive/5 p-4">
          <div className="flex items-start gap-3">
            <AlertTriangle className="mt-0.5 h-5 w-5 shrink-0 text-destructive" />
            <div>
              <p className="font-semibold text-destructive text-sm">Alerty aktywne</p>
              <div className="mt-2 flex flex-wrap gap-2">
                {alertSensors.filter((s) => !s.alertMuted).map((s) => (
                  <span key={s.id} className="inline-flex items-center gap-1.5 rounded-full bg-destructive/15 px-3 py-1 text-xs font-medium text-destructive">
                    <span className={cn("h-2 w-2 rounded-full", getTempZone(s.lastTemperature, s.minTempAlert, s.maxTempAlert) === "danger" ? "bg-destructive" : "bg-orange-400")} />
                    {s.roomName}: {formatTemp(s.lastTemperature, settings.tempUnit)} {s.lastHumidity != null ? `· ${formatHumidity(s.lastHumidity)}` : ""}
                  </span>
                ))}
              </div>
            </div>
          </div>
        </section>
      )}

      {withTemp.length > 1 && (
        <section className="grid gap-3 sm:grid-cols-2">
          <MiniExtreme icon={<TrendingDown className="h-4 w-4" />} title="Najchłodniej" sensor={minSensor} value={formatTemp(minSensor?.lastTemperature, settings.tempUnit)} />
          <MiniExtreme icon={<TrendingUp className="h-4 w-4" />} title="Najcieplej" sensor={maxSensor} value={formatTemp(maxSensor?.lastTemperature, settings.tempUnit)} />
        </section>
      )}

      {pinnedSensors.length > 0 && (
        <section>
          <h2 className="mb-3 font-display text-sm font-semibold uppercase tracking-widest text-muted-foreground">Przypięte</h2>
          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {pinnedSensors.map((s) => <SensorCard key={s.id} sensor={s} onTogglePin={() => handlePin(s)} onToggleMute={() => handleMute(s)} onListen={() => { listen(s); }} />)}
          </div>
        </section>
      )}

      <section>
        {(sensors.length > 0) && (
          <div className="mb-4 flex items-center justify-between">
            <h2 className="font-display text-xl font-bold">{pinnedSensors.length > 0 ? "Pozostałe pomieszczenia" : "Czujniki"}</h2>
            <span className="text-xs text-muted-foreground">{connected.length} online · {sensors.length} zapisanych</span>
          </div>
        )}
        {sensors.length === 0 ? (
          <div className="rounded-3xl border-2 border-dashed border-border p-16 text-center">
            <div className="mx-auto mb-4 flex h-16 w-16 items-center justify-center rounded-3xl bg-muted"><Thermometer className="h-8 w-8 text-muted-foreground" /></div>
            <h3 className="font-display text-lg font-bold">Brak czujników</h3>
            <p className="mx-auto mt-1 max-w-xs text-sm text-muted-foreground">Dodaj ELA Blue PUCK T/RHT i uruchom monitoring BLE.</p>
            <Button onClick={() => setAddOpen(true)} className="mt-6"><Plus className="mr-2 h-4 w-4" /> Dodaj pierwszy czujnik</Button>
          </div>
        ) : (
          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {cards.map((s) => <SensorCard key={s.id} sensor={s} onTogglePin={() => handlePin(s)} onToggleMute={() => handleMute(s)} onListen={() => { listen(s); }} />)}
          </div>
        )}
      </section>
      <AddSensorModal open={addOpen} onOpenChange={setAddOpen} onAdded={refresh} />
    </div>
  );
}

function StatPill({ icon, label, value, sub }: { icon: ReactNode; label: string; value: string; sub?: string }) {
  return <div className="rounded-2xl bg-white/15 px-4 py-3 backdrop-blur"><div className="flex items-center gap-2 text-[10px] uppercase tracking-widest opacity-70">{icon}{label}</div><div className="mt-1 font-display text-2xl font-black leading-none">{value}</div>{sub && <div className="mt-1 text-[11px] opacity-65">{sub}</div>}</div>;
}

function MiniExtreme({ icon, title, sensor, value }: { icon: ReactNode; title: string; sensor: any; value: string }) {
  return <div className="rounded-2xl border bg-card p-4"><div className="flex items-center gap-2 text-xs text-muted-foreground">{icon}{title}</div><div className="mt-1 flex items-end justify-between gap-3"><div className="font-display text-2xl font-black">{value}</div><div className="text-sm font-semibold">{sensor?.roomName ?? "—"}</div></div></div>;
}
