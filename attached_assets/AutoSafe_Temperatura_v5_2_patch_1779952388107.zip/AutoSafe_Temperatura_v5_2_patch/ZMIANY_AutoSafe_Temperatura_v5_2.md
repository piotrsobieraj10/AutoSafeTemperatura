# AutoSafe_Temperatura_v5.2

Poprawka skupiona na realnym odczycie ELA Blue PUCK T/RHT w PWA.

## Najważniejsze zmiany

- przycisk **Nasłuchuj BLE** nie kończy się już od razu komunikatem o braku cache Chrome,
- jeśli `navigator.bluetooth.getDevices()` nie zwróci zapisanego urządzenia, aplikacja uruchamia **requestLEScan** i dopasowuje czujnik po nazwie, np. `P T EN 81F7F2`,
- jeśli `requestLEScan` nie jest dostępne, aplikacja otwiera ponowny wybór urządzenia przez `requestDevice`,
- dekoder nadal obsługuje realny format z nRF Connect: `0x2A6E` temperatura `int16LE / 100`, `0x2A6F` wilgotność, `0x0757` bateria mV,
- dodano duży widoczny przycisk **Nasłuchuj BLE / odśwież reklamę** na ekranie czujników,
- na kartach dashboardu przycisk nasłuchu jest widoczny także na telefonie, nie tylko po hover,
- statusy są czytelniejsze: „Nasłuch BLE aktywny”, „szukam nazwy czujnika”, „odebrano ramkę”,
- wersja w UI: `AutoSafe_Temperatura_v5.2`.

## Test na telefonie

1. Zamknij nRF Connect.
2. Otwórz AutoSafe Temperatura w Chrome na Androidzie.
3. Wejdź w Czujniki.
4. Kliknij **Nasłuchuj BLE** przy czujniku.
5. Jeśli Chrome pokaże wybór urządzenia, wybierz dokładnie ten sam czujnik, np. `P T EN 81F7F2`.
6. Poczekaj 10–30 sekund przy czujniku.
7. Temperatura powinna pokazać się z ramki `0x2A6E`.
