# AutoSafe_Temperatura_v5.2 — patch

Wgraj ten ZIP do Replit i zastosuj go na istniejącym projekcie AutoSafeTemperatura z wersją v5.1.

## Co robi patch

- naprawia problem „brak cache Chrome”,
- po kliknięciu **Nasłuchuj BLE** próbuje `requestLEScan` i dopasowuje czujnik po nazwie, np. `P T EN 81F7F2`,
- jeśli `requestLEScan` nie jest dostępne, otwiera ponowny wybór czujnika przez `requestDevice`,
- dekoduje realne ramki ELA: `0x2A6E` temperatura, `0x2A6F` wilgotność, `0x0757` bateria mV,
- dodaje duży widoczny przycisk **Nasłuchuj BLE**,
- ustawia wersję UI na `AutoSafe_Temperatura_v5.2`.

## Po zastosowaniu

Uruchom:

```bash
npm run build
```

Test na telefonie: zamknij nRF Connect, kliknij **Nasłuchuj BLE** przy czujniku i wybierz ten sam czujnik w oknie Chrome, jeśli przeglądarka o to poprosi.
