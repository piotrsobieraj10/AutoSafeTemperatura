# AutoSafe_Temperatura_v5.3

Poprawka po testach na telefonie z ELA Blue PUCK T/RHT.

## Najważniejsza zmiana

W v5.2 aplikacja uruchamiała `requestLEScan`, ale Chrome/Replit potrafił pokazywać status „Nasłuch BLE aktywny”, nie przekazując do aplikacji realnych ramek `serviceData` / `manufacturerData`. Efekt: status „Nasłuch”, ale temperatura i bateria dalej były puste.

W v5.3 ręczne kliknięcie **Nasłuchuj BLE** działa inaczej:

1. Aplikacja otwiera systemowe okno wyboru Bluetooth przez `requestDevice`.
2. Użytkownik wybiera dokładnie zapisany czujnik, np. `P T EN 81F7B`.
3. Aplikacja uruchamia `watchAdvertisements()` na realnym obiekcie `BluetoothDevice`.
4. Dopiero jako fallback używany jest `requestLEScan`.

To omija problem „brak cache Chrome” i problem pustego `requestLEScan`.

## Dekodowanie zostaje bez zmian

- `0x2A6E` → temperatura `int16LE / 100`
- `0x2A6F` → wilgotność `uint16LE / 100`
- `0x0757` → bateria z dwóch ostatnich bajtów jako mV

## UI

- Wersja w UI: `AutoSafe_Temperatura_v5.3`.
- Przycisk na karcie: `Nasłuchuj BLE / wybierz czujnik`.
- Komunikaty wyjaśniają, że trzeba wskazać ten sam czujnik w oknie Chrome.

## Test

1. Zamknij nRF Connect.
2. W AutoSafe Temperatura kliknij `Nasłuchuj BLE / wybierz czujnik`.
3. W oknie Bluetooth wybierz dokładnie ten sam czujnik.
4. Poczekaj 10–30 sekund blisko czujnika.
5. Diagnostyka powinna pokazać `serviceData` i/lub `manufacturerData`, a karta temperaturę.
