# AutoSafe_Temperatura_v3 — plan przejścia z PWA na normalną aplikację Android APK

Ta paczka nadal działa jako PWA, ale ma przygotowane kroki pod wersję instalowaną jako aplikacja Android.

## Zalecana droga

1. Najpierw uruchom PWA i sprawdź ekran oraz motywy:
   ```bash
   npm install
   npm run dev
   ```

2. Gdy PWA działa, przygotuj Capacitor:
   ```bash
   npm run mobile:init
   ```

3. Skopiuj przykład konfiguracji:
   ```bash
   cp capacitor.config.example.ts capacitor.config.ts
   ```

4. Dodaj Androida:
   ```bash
   npm run mobile:add:android
   ```

5. Zbuduj i zsynchronizuj:
   ```bash
   npm run mobile:sync
   ```

6. Otwórz projekt w Android Studio:
   ```bash
   npm run mobile:open:android
   ```

## Bluetooth BLE

Do natywnego Bluetooth BLE najlepiej użyć wtyczki:

```bash
npm install @capacitor-community/bluetooth-le
npx cap sync android
```

W Androidzie 12+ trzeba obsłużyć uprawnienia Bluetooth Nearby Devices, szczególnie:

- `BLUETOOTH_SCAN`
- `BLUETOOTH_CONNECT`
- `ACCESS_FINE_LOCATION` tylko jeśli wymagane przez starsze urządzenia lub konkretne skanowanie

## Kolejny krok techniczny

W następnej wersji można dodać osobny serwis `nativeBleService.ts`, który będzie używał `@capacitor-community/bluetooth-le` zamiast Web Bluetooth, gdy aplikacja działa jako Android APK.
