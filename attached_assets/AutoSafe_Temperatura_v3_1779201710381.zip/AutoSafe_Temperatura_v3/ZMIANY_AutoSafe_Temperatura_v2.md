# AutoSafe_Temperatura_v2 — opis zmian

## Co poprawiono względem pierwotnej paczki

1. Zmieniono branding z „Termo” na „AutoSafe Temperatura”.
2. Dodano czarno-złotą kolorystykę premium pasującą do AutoSafe.
3. Dodano komponent logo/ikony AS w tarczy oraz ikonę PWA `public/icon.svg`.
4. Dodano manifest PWA `public/manifest.webmanifest`.
5. Dodano stałą wersję aplikacji `AutoSafe_Temperatura_v2`.
6. Rozbudowano dashboard: średnia temperatura, liczba alertów, status czujników, ostatni odczyt.
7. Dodano ręczne dodawanie czujnika po nazwie Bluetooth i/lub MAC.
8. Poprawiono modal dodawania czujnika: wybór skanowania albo ręcznego wpisania danych.
9. Dodano obsługę opisu/lokalizacji czujnika, np. „przy piecu”.
10. Dodano przycisk „Odczytaj teraz” w zakładce Czujniki.
11. Dodano `readingService.ts`, który zapisuje odczyt, aktualizuje status i dopisuje pomiar do historii.
12. Rozbudowano edycję czujnika: profil, nazwa Bluetooth, opis, progi temperatury i wilgotności.
13. Poprawiono wykres historii: odświeżanie po nowych danych oraz dodanie wilgotności na drugiej osi.
14. Dodano eksport historii pomiarów do CSV.
15. Dodano czyszczenie historii pomiarów.
16. Dodano backup/import danych aplikacji do JSON.
17. Dodano ustawienia świeżości danych i docelowego interwału odczytu.
18. Poprawiono mechanizm odświeżania danych w localStorage przez wysyłanie eventu `storage` po zapisie.
19. Utrzymano tryb demo, ale lepiej wkomponowano go w UI.
20. Dodano README z instrukcją uruchomienia i ograniczeniami Web Bluetooth.

## Ważna informacja techniczna

Nie udało się wykonać pełnego `npm install` i `npm run build` w środowisku roboczym, ponieważ instalacja zależności przekroczyła limit czasu. Wykonałem natomiast statyczne sprawdzenie składni plików TypeScript/TSX przez `typescript.transpileModule` — wynik: `TRANSPILE_OK`.

