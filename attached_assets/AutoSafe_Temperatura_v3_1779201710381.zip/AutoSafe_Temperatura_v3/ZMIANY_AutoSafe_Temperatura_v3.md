# AutoSafe_Temperatura_v3 — zmiany

## Motywy

- Dodano trzy tryby wyglądu: **Auto**, **Jasny**, **Ciemny**.
- Tryb **Auto** dopasowuje aplikację do ustawień systemowych telefonu/komputera.
- Jasny tryb jest mniej męczący w dzień, ale dalej zachowuje złote akcenty AutoSafe.
- Ciemny tryb zostaje w stylu premium: czarny/grafit + złoto.
- Aplikacja zapamiętuje wybrany motyw w `localStorage`.
- Dodano szybkie ustawienie klasy `dark` przed renderowaniem strony, żeby ograniczyć miganie motywu przy starcie.

## Branding AutoSafe

- Zostaje złote logo AutoSafe.
- Zostaje nazwa **AutoSafe Temperatura**.
- Kolory PWA/manifestu zostały dopasowane do jaśniejszego startu aplikacji.

## Przygotowanie pod normalną aplikację Android APK

- Dodano `capacitor.config.example.ts`.
- Dodano plan techniczny `ANDROID_APK_PLAN_AutoSafe_Temperatura_v3.md`.
- Dodano pomocnicze komendy w `package.json`:
  - `mobile:init`
  - `mobile:add:android`
  - `mobile:sync`
  - `mobile:open:android`

## Uwaga

Ta wersja nadal jest PWA. Pełna natywna obsługa Bluetooth BLE dla APK powinna zostać dodana w kolejnej wersji po testach na telefonie z Androidem i konkretnym czujnikiem, np. ELA Blue PUCK RHT/T.
