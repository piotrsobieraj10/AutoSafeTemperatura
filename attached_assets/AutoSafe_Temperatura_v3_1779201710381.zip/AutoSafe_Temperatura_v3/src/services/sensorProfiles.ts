import type { SensorProfile } from "@/types/sensor";

// Standardowy GATT Health Thermometer Service
// Service: 0x1809, Characteristic Temperature Measurement: 0x2A1C
const healthThermometer: SensorProfile = {
  id: "gatt-health-thermometer",
  name: "Standard GATT Health Thermometer",
  manufacturer: "Bluetooth SIG",
  serviceUuid: "health_thermometer",
  characteristicUuid: "temperature_measurement",
  supportsTemperature: true,
  supportsHumidity: false,
  source: "gatt",
  decode: (data) => {
    // flags(1) + float32 IEEE-11073
    const flags = data.getUint8(0);
    const mantissa =
      data.getUint8(1) | (data.getUint8(2) << 8) | (data.getUint8(3) << 16);
    const signedMantissa = mantissa & 0x800000 ? mantissa - 0x1000000 : mantissa;
    const exponent = data.getInt8(4);
    const temperature = signedMantissa * Math.pow(10, exponent);
    const isFahrenheit = (flags & 0x01) !== 0;
    return {
      temperature: isFahrenheit ? ((temperature - 32) * 5) / 9 : temperature,
    };
  },
};

// Environmental Sensing Service (ESS) — wiele DIY/ESP32
// Service: 0x181A, Char Temperature: 0x2A6E (sint16, 0.01°C), Humidity: 0x2A6F (uint16, 0.01%)
const environmentalSensing: SensorProfile = {
  id: "gatt-ess-temperature",
  name: "Environmental Sensing (ESS) — Temperatura",
  manufacturer: "Bluetooth SIG",
  serviceUuid: "environmental_sensing",
  characteristicUuid: "temperature",
  supportsTemperature: true,
  supportsHumidity: false,
  source: "gatt",
  decode: (data) => ({ temperature: data.getInt16(0, true) / 100 }),
};

const environmentalHumidity: SensorProfile = {
  id: "gatt-ess-humidity",
  name: "Environmental Sensing (ESS) — Wilgotność",
  manufacturer: "Bluetooth SIG",
  serviceUuid: "environmental_sensing",
  characteristicUuid: "humidity",
  supportsTemperature: false,
  supportsHumidity: true,
  source: "gatt",
  decode: (data) => ({ humidity: data.getUint16(0, true) / 100 }),
};

// Xiaomi LYWSD03MMC (przykład — uproszczony)
const xiaomiLywsd03: SensorProfile = {
  id: "xiaomi-lywsd03mmc",
  name: "Xiaomi LYWSD03MMC",
  manufacturer: "Xiaomi",
  serviceUuid: "ebe0ccb0-7a0a-4b0c-8a1a-6ff2997da3a6",
  characteristicUuid: "ebe0ccc1-7a0a-4b0c-8a1a-6ff2997da3a6",
  supportsTemperature: true,
  supportsHumidity: true,
  source: "gatt",
  decode: (data) => ({
    temperature: data.getInt16(0, true) / 100,
    humidity: data.getUint8(2),
  }),
};

export const sensorProfiles: SensorProfile[] = [
  healthThermometer,
  environmentalSensing,
  environmentalHumidity,
  xiaomiLywsd03,
];

export const getProfile = (id?: string): SensorProfile | undefined =>
  sensorProfiles.find((p) => p.id === id);
