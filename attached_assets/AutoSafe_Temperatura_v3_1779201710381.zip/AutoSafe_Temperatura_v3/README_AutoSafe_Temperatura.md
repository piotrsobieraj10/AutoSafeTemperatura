# AutoSafe Temperatura v2

Aplikacja do lokalnego monitorowania temperatury i wilgotności z czujników Bluetooth BLE.

## Najważniejsze funkcje

- dashboard z temperaturą pomieszczeń,
- czujniki przypisywane do pomieszczeń,
- dodawanie przez skanowanie Bluetooth albo ręcznie po nazwie/MAC,
- profile GATT dla popularnych sposobów odczytu,
- ręczny odczyt „Odczytaj teraz” dla urządzeń dostępnych w bieżącej sesji przeglądarki,
- historia pomiarów z wykresem temperatury i wilgotności,
- eksport historii do CSV,
- backup/import danych aplikacji do JSON,
- tryb demo,
- styl AutoSafe: czarny/złoty, logo AS i manifest PWA.

## Ważne ograniczenie Web Bluetooth

Przeglądarki często nie udostępniają prawdziwego adresu MAC urządzenia BLE. Aplikacja zapisuje bezpieczny `device.id`, a MAC można dopisać ręcznie. Na iOS Web Bluetooth nie działa w standardowej przeglądarce. Do pełnego monitoringu 24/7 najlepszy będzie później gateway BLE, np. Raspberry Pi albo ESP32.

## Uruchomienie

```bash
npm install
npm run dev
```

## Build

```bash
npm run build
```

