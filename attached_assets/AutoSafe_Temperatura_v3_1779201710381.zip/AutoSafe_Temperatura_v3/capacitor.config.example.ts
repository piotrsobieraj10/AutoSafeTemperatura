import type { CapacitorConfig } from "@capacitor/cli";

const config: CapacitorConfig = {
  appId: "immo.autosafe.temperatura",
  appName: "AutoSafe Temperatura",
  webDir: "dist",
  server: {
    androidScheme: "https",
  },
  plugins: {
    BluetoothLe: {
      displayStrings: {
        scanning: "AutoSafe skanuje czujniki Bluetooth w pobliżu...",
      },
    },
  },
};

export default config;
