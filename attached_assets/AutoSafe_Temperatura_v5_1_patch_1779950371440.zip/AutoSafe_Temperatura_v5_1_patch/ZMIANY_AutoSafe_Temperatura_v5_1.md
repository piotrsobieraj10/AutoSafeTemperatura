# AutoSafe_Temperatura_v5.1

Poprawka przygotowana pod realne ramki BLE z czujników ELA Blue PUCK widoczne w nRF Connect.

## Najważniejsze zmiany

- Dekodowanie temperatury ELA Blue PUCK T z BLE advertising:
  - AD Type `0x16`, UUID `0x2A6E`, wartość `int16LE / 100`.
  - Przykład: `6E 2A 1C 09` → `23.32°C`.
- Przygotowanie dekodowania wilgotności dla Blue PUCK RHT:
  - UUID `0x2A6F`, wartość `uint16LE / 100`.
- Dekodowanie baterii ELA z Manufacturer Data:
  - Company ID `0x0757`.
  - Ostatnie 2 bajty payloadu jako `uint16LE` w mV.
  - Przykład: `FF 57 07 F2 E9 0B` → `3049 mV`.
- Aplikacja nie wymusza już klasycznego `CONNECT/GATT` dla ELA Blue PUCK T/RHT.
- Po wyborze czujnika aplikacja uruchamia `watchAdvertisements()` i czeka na `advertisementreceived`.
- Dodany tryb skanowania po nazwach: `P T`, `P T EN`, `P RHT`, `BPUCK`, `ELA`.
- Dodany tryb awaryjny: skanowanie wszystkich urządzeń BLE.
- Czujnik po dodaniu dostaje status `Oczekuje`, a nie martwe `Offline`.
- Karty pokazują nazwę Bluetooth, np. `P T EN 81171A`, a nie tylko `Salon`.
- Dodana diagnostyka BLE:
  - `serviceData`,
  - `manufacturerData`,
  - `RSSI`,
  - ostatni odczyt,
  - przycisk kopiowania diagnostyki.
- Dodany przycisk „Odśwież BLE / nasłuchuj reklam”.
- Wersja w UI: `AutoSafe_Temperatura_v5.1`.

## Jak testować

1. Otwórz aplikację na Androidzie w Chrome po HTTPS/Replit.
2. Wejdź w „Czujniki”.
3. Usuń stare duplikaty, jeśli były dodane wcześniej jako `Salon` bez danych.
4. Kliknij „Dodaj”.
5. Wybierz „Skanuj ELA Blue PUCK T/RHT”.
6. Wybierz urządzenie `P T EN ...` albo `P RHT ...`.
7. Zapisz czujnik.
8. Na karcie kliknij „Odśwież BLE / nasłuchuj reklam”.
9. Poczekaj kilka–kilkanaście sekund na ramkę BLE.
10. Sprawdź diagnostykę BLE na ekranie czujnika.

Jeśli Chrome nie udostępni ramek `serviceData`, aplikacja pokaże czujnik jako zapisany, ale diagnostyka będzie pusta. Wtedy najpewniejszą drogą będzie natywna aplikacja Android/Capacitor, bo nRF Connect potwierdza, że czujnik nadaje dane poprawnie.
