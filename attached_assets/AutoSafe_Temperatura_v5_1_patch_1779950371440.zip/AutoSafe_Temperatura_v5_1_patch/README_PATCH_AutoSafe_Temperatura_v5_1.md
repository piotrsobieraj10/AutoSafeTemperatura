# Patch AutoSafe_Temperatura_v5.1

Wgraj tę paczkę do Replit i nadpisz pliki w istniejącym projekcie.

Najpierw zrób backup:

```bash
git status
git branch backup-przed-v5-1
```

Potem zastosuj patch, uruchom:

```bash
npm run build
```

Po udanym teście:

```bash
git add .
git commit -m "AutoSafe_Temperatura_v5.1 - dekodowanie BLE ELA Blue PUCK"
git push
```
