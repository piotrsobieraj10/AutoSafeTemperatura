# AutoSafe_Temperatura_v5.6

Poprawka porządkująca aplikację przed kolejną aktualizacją produkcyjną.

## Najważniejsze zmiany

- Nowy pulpit „Centrum monitoringu” z filtrem: Wszystkie / Uwaga / Online / Offline.
- Sekcja „Wymaga uwagi” pokazująca tylko czujniki z problemami.
- Tryby monitoringu BLE: szybki odczyt 30 s, monitoring 5 min i monitoring ciągły przy otwartej aplikacji.
- Możliwość zatrzymania aktywnego monitoringu BLE.
- Lepsze pierwsze uruchomienie: krótka porada i przycisk dodania czujnika.
- Raport PDF/druk: aplikacja otwiera raport HTML, który można wydrukować lub zapisać jako PDF.
- Historia alertów na ekranie Historia.
- Lepsze blokowanie duplikatów czujników po nazwie Bluetooth, również po normalizacji spacji i znaków.
- Bateria w mV brana pod uwagę w alertach słabej baterii.
- Nowe ustawienia: domyślny tryb monitoringu, porady po pierwszym uruchomieniu, opcje diagnostyki.
- Zmieniona wersja UI na `AutoSafe_Temperatura_v5.6`.

## Co zostaje bez zmian

- Prawdziwe złote logo AutoSafe z v5.5.
- Dekodowanie ELA Blue PUCK:
  - `0x2A6E` temperatura `int16LE / 100`,
  - `0x2A6F` wilgotność,
  - `0x0757` bateria w mV.
- Dane nadal są zapisywane lokalnie w telefonie/przeglądarce.
- Diagnostyka BLE pozostaje opcjonalna w ustawieniach.

## Test po wdrożeniu

1. Uruchom aplikację i sprawdź wersję w nagłówku: `AutoSafe_Temperatura_v5.6`.
2. Kliknij `Monitoruj wszystkie` i wybierz tryb 30 s / 5 min.
3. Sprawdź, czy czujniki aktualizują temperaturę, wilgotność, baterię i RSSI.
4. Wejdź w Historia i sprawdź raport PDF/druk.
5. Spróbuj dodać ten sam czujnik ponownie — aplikacja powinna zablokować duplikat.
