// ============================================================
// bluetoothService.ts v2 — uniwersalny skaner BLE
// Obsługuje: ELA, RuuviTag, Govee, Inkbird, SensorPush, Xiaomi
// ============================================================

import type { DecodedData, Sensor } from "@/types/sensor";
import {
  ALL_COMPANY_IDS,
  detectProfileByCompanyId,
  detectProfileByName,
  getProfile,
  sensorProfiles,
} from "./sensorProfiles";

// ── Typy BT API ──────────────────────────────────────────────

interface NavWithBT extends Navigator {
  bluetooth?: BTAPI;
}
interface BTAPI {
  requestDevice: (o: RequestDeviceOptions) => Promise<BTDevice>;
  getAvailability?: () => Promise<boolean>;
}
interface RequestDeviceOptions {
  acceptAllDevices?: boolean;
  filters?: object[];
  optionalServices?: string[];
  optionalManufacturerData?: number[];
}
export interface BTDevice {
  id: string;
  name?: string | null;
  gatt?: {
    connected: boolean;
    connect: () => Promise<BTGATTServer>;
    disconnect: () => void;
  };
  watchAdvertisements?: (o?: { signal?: AbortSignal }) => Promise<void>;
  addEventListener?: (t: string, l: (e: BTAdvEvent) => void) => void;
  removeEventListener?: (t: string, l: (e: BTAdvEvent) => void) => void;
}
interface BTGATTServer {
  getPrimaryService: (u: string) => Promise<BTGATTService>;
}
interface BTGATTService {
  getCharacteristic: (u: string) => Promise<BTGATTChar>;
}
interface BTGATTChar {
  readValue: () => Promise<DataView>;
  startNotifications?: () => Promise<BTGATTChar>;
  addEventListener?: (t: string, l: (e: { target: { value: DataView } }) => void) => void;
  removeEventListener?: (t: string, l: (e: { target: { value: DataView } }) => void) => void;
}
export interface BTAdvEvent extends Event {
  device: BTDevice;
  name?: string;
  rssi?: number;
  txPower?: number;
  manufacturerData?: Map<number, DataView>;
  serviceData?: Map<string, DataView>;
}

// ── Cache ────────────────────────────────────────────────────

const deviceCache = new Map<string, BTDevice>();
const advControllers = new Map<string, AbortController>();

// ── Availability ────────────────────────────────────────────

const getBT = (): BTAPI | undefined => (navigator as NavWithBT).bluetooth;

export const isBluetoothAvailable = async (): Promise<boolean> => {
  const bt = getBT();
  if (!bt) return false;
  try { return bt.getAvailability ? await bt.getAvailability() : true; }
  catch { return false; }
};

export const isAdvertisementScanSupported = (): boolean => {
  const proto = typeof BluetoothDevice !== "undefined"
    ? (BluetoothDevice.prototype as unknown as Record<string, unknown>)
    : null;
  return !!(proto?.watchAdvertisements);
};

// ── Universal scan ──────────────────────────────────────────

export interface ScanResult {
  device: BTDevice;
  detectedProfileId: string | null;
  data: DecodedData;
}

export type ScanCallback = (result: ScanResult) => void;

/**
 * Universal scan — obsługuje wszystkie obsługiwane czujniki.
 * Wyświetla systemowy dialog wyboru urządzenia.
 * Po wyborze próbuje watchAdvertisements (jeśli wspierany).
 */
export const scanForDevice = async (
  onData: ScanCallback,
  onError?: (e: Error) => void
): Promise<BTDevice | null> => {
  const bt = getBT();
  if (!bt) throw new Error("Web Bluetooth niedostępne. Użyj Chrome lub Edge.");

  const optionalServices = sensorProfiles
    .filter((p) => p.serviceUuid && !p.serviceUuid.startsWith("0x"))
    .map((p) => p.serviceUuid!);

  const device = await bt.requestDevice({
    acceptAllDevices: true,
    optionalServices,
    optionalManufacturerData: ALL_COMPANY_IDS,
  });

  if (!device?.id) return null;
  deviceCache.set(device.id, device);

  // Auto-detect profilu po nazwie
  const nameProfile = detectProfileByName(device.name);

  // Uruchom advertisement watch jeśli wspierany
  if (typeof device.watchAdvertisements === "function" && device.addEventListener) {
    await startAdvWatch(device, nameProfile, onData, onError);
  }

  return device;
};

// ── Advertisement Watch ─────────────────────────────────────

export const startAdvWatch = async (
  device: BTDevice,
  hintProfileId: string | null,
  onData: ScanCallback,
  onError?: (e: Error) => void
): Promise<AbortController> => {
  const controller = new AbortController();
  advControllers.set(device.id, controller);

  const handler = (event: BTAdvEvent) => {
    const rssi = event.rssi ?? undefined;
    if (!event.manufacturerData) return;

    for (const [companyId, rawData] of event.manufacturerData) {
      // Auto-detect po company id
      const profileId =
        detectProfileByCompanyId(companyId, rawData) ??
        hintProfileId;

      if (!profileId) continue;

      const profile = getProfile(profileId);
      if (!profile?.decodeAdvertisement) continue;

      try {
        const decoded = profile.decodeAdvertisement(rawData, rssi);
        if (decoded.temperature !== undefined || decoded.humidity !== undefined) {
          onData({ device, detectedProfileId: profileId, data: { ...decoded, rssi } });
        }
      } catch (e) {
        onError?.(e instanceof Error ? e : new Error(String(e)));
      }
    }
  };

  if (device.addEventListener && typeof device.watchAdvertisements === "function") {
    device.addEventListener("advertisementreceived", handler);
    try {
      await device.watchAdvertisements({ signal: controller.signal });
    } catch (e) {
      // Nie blokuj jeśli watchAdvertisements rzuci — to opcjonalne
      console.warn("watchAdvertisements failed:", e);
    }
  }

  controller.signal.addEventListener("abort", () => {
    device.removeEventListener?.("advertisementreceived", handler);
  });

  return controller;
};

export const stopAdvWatch = (deviceId: string) => {
  advControllers.get(deviceId)?.abort();
  advControllers.delete(deviceId);
};

// ── GATT read ───────────────────────────────────────────────

export const readGATT = async (
  device: BTDevice,
  serviceUuid: string,
  charUuid: string
): Promise<DataView> => {
  if (!device.gatt) throw new Error("Urządzenie nie udostępnia GATT.");
  const server = await device.gatt.connect();
  const service = await server.getPrimaryService(serviceUuid);
  const char = await service.getCharacteristic(charUuid);
  return char.readValue();
};

export const readSensorGATT = async (
  device: BTDevice,
  profileId: string
): Promise<DecodedData> => {
  const profile = getProfile(profileId);
  if (!profile?.serviceUuid || !profile?.characteristicUuid || !profile.decodeGatt) {
    throw new Error("Profil GATT niekompletny.");
  }
  const data = await readGATT(device, profile.serviceUuid, profile.characteristicUuid);
  return profile.decodeGatt(data);
};

export const disconnectGATT = (device: BTDevice) => device.gatt?.disconnect();

// ── Reconnect for saved sensors ─────────────────────────────

export const reconnectSensor = async (
  sensor: Sensor,
  onData: ScanCallback,
  onError?: (e: Error) => void
): Promise<boolean> => {
  const device = deviceCache.get(sensor.deviceId);
  if (!device) return false;

  const profile = getProfile(sensor.profileId);
  if (!profile) return false;

  if (profile.source === "advertisement") {
    stopAdvWatch(device.id);
    if (typeof device.watchAdvertisements === "function" && device.addEventListener) {
      await startAdvWatch(device, sensor.profileId, onData, onError);
      return true;
    }
    return false;
  }

  if (profile.source === "gatt") {
    try {
      const data = await readSensorGATT(device, sensor.profileId);
      onData({ device, detectedProfileId: sensor.profileId, data });
      return true;
    } catch (e) {
      onError?.(e instanceof Error ? e : new Error(String(e)));
      return false;
    }
  }

  return false;
};

export const getCachedDevice = (id: string) => deviceCache.get(id);
