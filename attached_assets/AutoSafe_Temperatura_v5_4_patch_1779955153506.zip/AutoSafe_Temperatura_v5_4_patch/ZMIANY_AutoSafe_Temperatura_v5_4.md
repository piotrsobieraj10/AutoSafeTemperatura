# AutoSafe_Temperatura_v5.4

Poprawka dopracowująca realny odczyt ELA Blue PUCK po testach na telefonie.

## Najważniejsze zmiany

- Przycisk **Nasłuchuj BLE** nie wymusza już za każdym razem ponownego wyboru czujnika w oknie Chrome.
- Aplikacja najpierw uruchamia `requestLEScan` i dopasowuje ramki po nazwie Bluetooth, np. `P T EN 81F7FB`.
- Okno wyboru Bluetooth (`requestDevice`) jest teraz tylko awaryjnym fallbackiem, gdy automatyczny skan po nazwie nie działa.
- Dodany wspólny aktywny skan BLE dla wielu czujników, żeby nie uruchamiać kilku niepotrzebnych skanów naraz.
- Status Online/Offline jest stabilniejszy: czujnik z ostatnią świeżą ramką wraca na **Online** i nie znika po chwilowym stanie „Nasłuch”.
- Czas uznania odczytu za świeży wydłużony do 120 sekund.
- Odczyty z różnych ramek są zachowywane osobno:
  - temperatura z `0x2A6E`,
  - wilgotność z `0x2A6F`,
  - bateria z `0x0757`.
- Jeśli następna ramka zawiera tylko temperaturę, aplikacja nie kasuje ostatnio znanej baterii ani wilgotności.
- Jeśli pojawi się wilgotność, profil czujnika automatycznie przełącza się na **ELA Blue Puck RHT**.
- Zmieniono wersję w UI na `AutoSafe_Temperatura_v5.4`.

## Jak testować

1. Zamknij nRF Connect.
2. Otwórz AutoSafe Temperatura w Chrome na Androidzie.
3. Przy czujniku kliknij **Nasłuchuj BLE / odśwież odczyt**.
4. Aplikacja powinna skanować po nazwie bez ponownego wybierania czujnika.
5. Sprawdź, czy temperatura pojawia się po kilku sekundach.
6. Bateria może pojawić się później, gdy czujnik nada ramkę `0x0757`; aplikacja nie powinna jej potem kasować.
7. Dla czujnika RHT sprawdź, czy po ramce `0x2A6F` pojawia się wilgotność.
