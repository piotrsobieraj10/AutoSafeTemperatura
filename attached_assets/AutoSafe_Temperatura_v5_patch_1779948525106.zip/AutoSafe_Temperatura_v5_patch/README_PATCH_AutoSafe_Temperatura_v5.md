# AutoSafe_Temperatura_v5 — patch

Zakres patcha:
- naprawa trybu demo: domyślnie wyłączony, bez crasha po wyłączeniu, czyszczenie tylko czujników DEMO,
- poprawiony motyw Auto / Jasny / Ciemny i poprawne klucze localStorage `thermo.v2.settings`,
- branding AutoSafe Temperatura + złote logo / favicon / manifest PWA,
- poprawione skanowanie Bluetooth pod ELA Blue PUCK RHT/T:
  - filtry po nazwach `P RHT`, `P T`, `BPUCK`, `ELA`,
  - dodatkowy tryb „Skanuj wszystkie BLE”,
  - konfiguracja otwiera się od razu po wyborze czujnika, nie czeka już na pierwszy odczyt,
  - dekoder Service Data 0x2A6E dla temperatury,
  - dekoder Service Data 0x2A6F dla wilgotności RHT,
  - dekoder Manufacturer Data ELA 0x0757 jako fallback,
- dodane ręczne dodanie czujnika po nazwie / identyfikatorze,
- dodany ekran awaryjny zamiast białego crasha „coś poszło nie tak”,
- eksport CSV, backup JSON i import JSON,
- blokada automatycznego tłumaczenia strony przez Chrome/Google Translate.

Jak wgrać:
1. Przed wgraniem zrób punkt powrotu w Replit/Git:
   `git branch backup-przed-v5 && git status`
2. Wgraj zawartość ZIP do katalogu projektu tak, aby nadpisała istniejące pliki w tych samych ścieżkach.
3. Uruchom:
   `npm install`
   `npm run build`
4. Test na telefonie Android/Chrome:
   - Ustawienia → Tryb demo OFF,
   - Czujniki → Dodaj → Skanuj ELA Blue PUCK RHT/T,
   - wybierz czujnik `P RHT...`,
   - poczekaj na ramkę BLE; jeśli nie ma danych, użyj „Skanuj wszystkie BLE”.

Uwagi:
- PWA na Androidzie zależy od wsparcia `watchAdvertisements()` w Chrome. Jeśli telefon/Chrome nie daje ramek advertising, czujnik można dodać i zapisać, ale pełny stabilny odczyt ELA RHT najlepiej będzie zrobić w kolejnym kroku jako Android APK przez Capacitor BLE.
- Wersja ustawiona w UI: `AutoSafe_Temperatura_v5`.
