# AutoSafe_Temperatura_v5.6.1 — hotfix stabilności Android Chrome

## Cel poprawki
Po zastosowaniu v5.5 + v5.6 na Android Chrome pojawiał się crash całej karty przeglądarki („Kurza twarz!”). Hotfix stabilizuje start aplikacji bez cofania działającego BLE i bez usuwania prawdziwego złotego logo AutoSafe.

## Najważniejsze zmiany
- wersja UI: `AutoSafe_Temperatura_v5.6.1`,
- dodany `AppErrorBoundary`, żeby zwykły błąd React nie wywracał całej aplikacji,
- naprawiona potencjalna pętla `autosafe:data-changed -> upsertSensor -> autosafe:data-changed`,
- status online/offline jest odświeżany rzadziej i tylko realne zmiany są zapisywane do localStorage,
- BLE nie startuje automatycznie po wejściu w aplikację; monitoring startuje tylko po kliknięciu użytkownika,
- wszystkie timery monitoringu mają cleanup,
- dodane czyszczenie starych cache/service workerów przy starcie,
- dodana bezpieczna sanitizacja danych localStorage,
- w ustawieniach dodany przycisk „Wyczyść dane aplikacji”.

## Zachowane z wcześniejszych wersji
- prawdziwe złote logo AutoSafe,
- motyw Auto/Jasny/Ciemny,
- `0x2A6E` temperatura,
- `0x2A6F` wilgotność,
- `0x0757` bateria,
- `Monitoruj wszystkie`,
- eksport CSV,
- backup/import JSON,
- diagnostyka BLE sterowana z ustawień.

## Test po wdrożeniu
1. Odśwież Preview/Replit na telefonie.
2. Jeśli Chrome nadal pokaże stary ekran błędu, wyczyść dane strony/cache i otwórz ponownie.
3. Sprawdź, czy aplikacja startuje i pokazuje wersję `AutoSafe_Temperatura_v5.6.1`.
4. Dopiero potem kliknij „Monitoruj wszystkie” albo „Nasłuchuj BLE”.
